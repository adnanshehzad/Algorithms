package lab11_undirected;

import java.util.ArrayList;


public class HasCycle extends BreadthFirstSearch {
	
	public HasCycle(Graph graph) {
		super(graph);
	}
	
	//TO-DO
	public boolean hasCycle() {
		return false;
	}

}
