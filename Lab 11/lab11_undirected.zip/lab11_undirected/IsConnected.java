package lab11_undirected;

public class IsConnected extends BreadthFirstSearch {
	public IsConnected(Graph graph) {
		super(graph);
	}

	//TO-DO
	public boolean isConnected() {
		return false;
	}
}
