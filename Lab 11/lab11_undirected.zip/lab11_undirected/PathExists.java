package lab11_undirected;



public class PathExists extends BreadthFirstSearch {
	
	public PathExists(Graph graph) {
		super(graph);
	}

	//TO-DO
	public boolean pathExists(Vertex u, Vertex v) {
		return false;
	}
	
}
